const Candy = require('./candy');
const Offer = require('./offer');
const Pinata = require('./pinata');

module.exports = {
    Candy,
    Offer,
    Pinata
}