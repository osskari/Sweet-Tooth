function PinataDto (id, name, maximumHits, currentHits) {
    this.id = id;
    this.name = name;
    this.maximumHits = maximumHits;
    this.currentHits = currentHits;
}

module.exports = PinataDto;