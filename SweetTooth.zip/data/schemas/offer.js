function Offer(id, name, candies) {
    this.id = id;
    this.name = name;
    this.candies = candies;
}

module.exports = Offer;